./compile.sh && cd protocols/ && ./compile.sh && cd ../clients && ./compile.sh
