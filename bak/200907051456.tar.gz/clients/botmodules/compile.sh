gcc --shared -fPIC botcb.cpp test.cpp -o libtest.so 
