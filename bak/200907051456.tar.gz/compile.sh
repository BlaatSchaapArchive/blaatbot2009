g++ main.cpp xmlParser.cpp -ldl -o blaat
