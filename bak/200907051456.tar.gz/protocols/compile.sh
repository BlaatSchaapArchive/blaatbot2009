g++ --shared -fPIC bci.cpp bpp.cpp irc.cpp ../xmlParser.cpp -o libirc.so -lpthread -ldl 
