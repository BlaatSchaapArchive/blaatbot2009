gcc --shared -fPIC bci.cpp bpp.cpp irc.cpp -o libirc.so -lpthread -ldl 
