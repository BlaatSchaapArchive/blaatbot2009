gcc --shared -fPIC bot.cpp bcp.cpp -o libbot.so -lpthread -ldl
