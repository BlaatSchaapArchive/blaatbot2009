#include "bcp.h" 
#include "../c.h"
#include "../bpi.h"
#include <vector>
using namespace std;

vector <cClient> clients;

void * bc_init (void * CI){
  char * path = getcwd(NULL,NULL);
  sConnectInfo * ConnectInfo = (sConnectInfo*)CI;
  if ( (CI->host || CI->ipv4 || CI->ipv6) && (CI->port) ) {      
    if (CI->prot) {
      void *lib;
      char *libname;
      libname = (char*) malloc (strlen(CI->prot) + strlen(path)+ 15);
      sprintf(libname,"%s/protocols/lib%s.so",path,protocol);
      lib = dlopen(libname, RTLD_LAZY);
      if (lib) {
        free(libname);
        libname = NULL;
        bp_id     = (t_f_pcar_v)  dlsym(lib, "bp_id"); 
        bp_client = (t_f_i_pchar) dlsym(lib, "bp_client");
        bp_init   = (t_f_pv_pv)   dlsym(lib, "bp_init"); 
//        bp_init   = (t_f_i_8pchar)dlsym(lib, "bp_init"); 
        if (bp_client) {
          if (bp_init) {
            if (!bp_client(client)) bp_init(host, ipv4, ipv6, port, nick, user, auth, password);
          } else {
            printf("Unable to initialise protocol (config) %s\n",protocol);          
            printf("%s\n",dlerror());
            dlclose(lib);
            bp_init = NULL;
            lib     = NULL;
          }
        } else {
        printf("Unable to initialise protocol (client) %s\n",protocol);          
        printf("%s\n",dlerror());
        dlclose(lib);
        bp_init = NULL;
        bp_client = NULL;
        lib       = NULL;
        }                
      } else {
        printf("Unable to load protocol %s\n",protocol);
        printf("%s\n",dlerror());
      }
    } else {
      printf("Protocol required\n");
    }
  } else {
  printf("Server and port are required\n");
  }
  free(path);
  cClient *c = new cClient();
  clients->push_back(c);
  void * p = bp_init(CI);
  if (p) {
    c->
  }

  return c;
}
//-----------------------------------------------------------------------------



void bc_message ( void * inst, char * targ,  char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->message(targ,nick,user,host,mess);
}

void bc_action  ( void * inst, char * targ,  char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->action(targ,nick,user,host,mess);
}

void bc_notice  ( void * inst, char * targ,  char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->notice(targ,nick,user,host,mess);
}

void bc_ctcp    ( void * inst, char * targ,  char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->ctcp(targ,nick,user,host,mess);
}

// Events
void bc_join( void * inst, char * targ,  char * nick,  char * user,  char * host){
  cClient *c;
  c=(cClient*)inst;
  c->join(targ,nick,user,host);
}

void bc_part( void * inst, char * targ,  char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->part(targ,nick,user,host,mess);
}

void bc_kick( void * inst, char * chan,  char * kick,  char * mess,  char * nick,  char * user,  char * host){
  cClient *c;
  c=(cClient*)inst;
  c->kick(chan,kick,mess,nick,user,host);
}

void bc_nick( void * inst, char * nick,  char * user,  char * host,  char * newn){
  cClient *c;
  c=(cClient*)inst;
  c->nick(nick,user,host,newn);
}

void bc_quit( void * inst, char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->quit(nick,user,host,mess);
}

void bc_mode( void * inst, char * nick,  char * user,  char * host,  char * mode, char * targ){
  cClient *c;
  c=(cClient*)inst;
  c->mode(nick,user,host,mode,targ);
}

void bc_channel_add     ( void * inst, char * chan,  char * nick,  char * user,  char * host,  char *serv,  char *mode,  char *real){
  cClient *c;
  c=(cClient*)inst;
  c->channel_add(chan, nick, user, host, serv, mode, real);
}


void bc_motd_begin      ( void * inst, char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->motd_begin(nick,user,host,mess);
}

void bc_motd            ( void * inst, char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->motd(nick,user,host,mess);
}

void bc_motd_end        ( void * inst, char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->motd_end(nick,user,host,mess);
}

void bc_motd_missing    ( void * inst ){
  cClient *c;
  c=(cClient*)inst;
  c->motd_missing();
}

void bc_nickchangefail  ( void * inst, char * oldn,  char * badn,  char * mess,  char * numb){
  cClient *c;
  c=(cClient*)inst;
  c->nickchangefail(oldn,badn,mess,numb);
}

void bc_unknown_message ( void * inst, char * targ,  char * nick,  char * user,  char * host,  char * mess){
  cClient *c;
  c=(cClient*)inst;
  c->unknown_message(targ,nick,user,host,mess);
}
