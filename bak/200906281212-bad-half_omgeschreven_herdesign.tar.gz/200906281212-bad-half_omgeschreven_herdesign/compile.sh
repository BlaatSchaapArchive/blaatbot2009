g++ main.cpp xmlParser.cpp bci.cpp -ldl -o blaat
