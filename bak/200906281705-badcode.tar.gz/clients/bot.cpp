#include <string.h> 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dlfcn.h>
#include "bot.h"
#include "bcp.h"
#include "../c.h"
#include "../xmlParser.h"

  cBot * client;
//-----------------------------------------------------------------------------

void __attribute__ ((constructor)) bpp_init(void){
  printf("Loading client library...\n");
}

//-----------------------------------------------------------------------------

void __attribute__ ((destructor)) bpp_fini(void){
  printf("Unloading client library...\n");
}

//-----------------------------------------------------------------------------

char * bc_id(void){
  return (char*)"blaat";
}

//-----------------------------------------------------------------------------
void * bc_init (void * P){
  return (void*) new cBot ( (cProtocol*)P );
}

//-----------------------------------------------------------------------------
//cClient::Blaat(){printf("Blaat");}

cBot::cBot(cProtocol * P){
  Protocol = P;
  XMLNode *t =  (XMLNode*)(Protocol->Connection->ConnectInfo->xml);
  xml = *t;
}

//-----------------------------------------------------------------------------
void cBot::welcome(const char * serv, const char * nick, const char * mess){
  if(nick) {
    mynick = (char*)malloc(strlen(nick)+1);
    strcpy(mynick,nick);
  }
  if (serv){
    myserv = (char*)malloc(strlen(serv)+1);
    strcpy(myserv,serv);
  }
}
//-----------------------------------------------------------------------------

void cBot::message (char * targ, char * nick, char * user, char * host, char * mess){
  printf("message: ");
  if (mess) { printf("%s\n",mess);
  char * blaat =  strtok (mess," ");
  char * mekker = strtok (NULL,"");
  if (blaat && mekker) 
    if ( strcasecmp("!test",blaat) ==0 )
      if (strcasecmp(targ,mynick))
        Protocol->privmsg    (targ,mekker);
      else
        Protocol->privmsg    (nick,mekker);
  }
}
//-----------------------------------------------------------------------------
void cBot::action  ( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("action: ");
  if (mess) printf("%s\n",mess);
}
//-----------------------------------------------------------------------------
void cBot::notice  ( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("notice: ");
  if (mess) printf("%s\n",mess);
}
//-----------------------------------------------------------------------------
void cBot::ctcp    ( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("ctcp: ");
  if (mess) printf("%s\n",mess);
}
//-----------------------------------------------------------------------------
void cBot::join( char * targ,  char * nick,  char * user,  char * host){
  printf("join: ");
  if (targ && nick && user && host) {
    printf("%s (%s@%s) joined %s\n",nick,user,host,targ);
  }
}
//-----------------------------------------------------------------------------
void cBot::part( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("part: ");
  if (targ && nick && user && host) {
    printf("%s (%s@%s) parted %s",nick,user,host,targ);
    if (mess) printf (" reason : %s",mess); 
    printf("\n");
  }
}
//-----------------------------------------------------------------------------
void cBot::kick( char * chan,  char * kick,  char * mess,  char * nick,  char * user,  char * host){
  printf("kick: ");
}
//-----------------------------------------------------------------------------
void cBot::nick( char * nick,  char * user,  char * host,  char * newn){
    if (newn && nick && user && host) {
      printf("%s (%s@%s) changed nick to%s",nick,user,host,newn);
    }
}
//-----------------------------------------------------------------------------
void cBot::quit( char * nick,  char * user,  char * host,  char * mess){
  printf("quit: ");
}
//-----------------------------------------------------------------------------
void cBot::mode( char * nick,  char * user,  char * host,  char * mode,     char * targ){
  printf("mode: ");
}
//-----------------------------------------------------------------------------
void cBot::channel_clear   ( char * chann){
}
//-----------------------------------------------------------------------------
void cBot::channel_add     ( char * chann,  char * nick,  char * user,  char * host,  char *serv,  char *mode,  char *real){
}
//-----------------------------------------------------------------------------
void cBot::motd_begin      ( char * nick,  char * user,  char * host,  char * mess){
}
//-----------------------------------------------------------------------------
void cBot::motd            ( char * nick,  char * user,  char * host,  char * mess){
}
//-----------------------------------------------------------------------------
void cBot::motd_end        ( char * nick,  char * user,  char * host,  char * mess){
}
//-----------------------------------------------------------------------------
void cBot::motd_missing    (){
}
//-----------------------------------------------------------------------------
void cBot::nickchangefail  ( char * oldn,  char * badn,  char * mess,  char * numb){
}
//-----------------------------------------------------------------------------
void cBot::unknown_message ( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("Unimplemented Message Received! " );
  printf("%s %s %s %s %s\n", targ, nick, user, host, mess);

}
//-----------------------------------------------------------------------------
void cBot::JoinChannels(){
  XMLNode ChannelToJoin = xml.getChildNode("channel");
  while ( !ChannelToJoin.isEmpty() ) {
    Protocol->join(ChannelToJoin.getText());
  ChannelToJoin = xml.getChildNode("channel");
  }
}
