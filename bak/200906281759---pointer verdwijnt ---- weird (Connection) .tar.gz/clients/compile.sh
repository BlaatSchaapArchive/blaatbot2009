g++ --shared -fPIC bot.cpp bcp.cpp ../xmlParser.cpp -o libbot.so -lpthread -ldl
