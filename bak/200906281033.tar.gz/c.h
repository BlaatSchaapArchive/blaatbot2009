#ifndef _BLAAT_CLASSES_
#define _BLAAT_CLASSES_
#include <vector>

class cProtocol;
class cClient;
class cConnection;

using namespace std;
class cProtocol{
  private:
  //pthread_t receivethread;
  protected:  
  cClient * Client;  

  public:
  //virtual cClient (cConnection *C);
  void SetClient (cClient *C) {Client = C;};
  virtual void   StartThread ()=0;
  virtual void   ReceiveThread ()=0;
//  void   SendLogin     (char * user, char * nick, char * pass);
  virtual void   SendLogin     ()=0;
  virtual void   SendAuth      ()=0;

  virtual void sendNICK   (const char *nick)=0;
  virtual void sendPRIVMSG(const char *target, const char *message)=0;
  virtual void sendNOTICE (const char *target, const char *message)=0;
  virtual void sendACTION (const char *target, const char *message)=0;
  virtual void sendMODE   (const char *target, const char *mode)=0;
  virtual void sendAWAY   (const char *reason)=0;
  virtual void sendBACK()=0;
  virtual void sendQUIT   (const char *reason)=0;
  virtual void sendRAW    (const char *raw)=0;

};


struct sConnectInfo {
  char * host; 
  char * ipv4; 
  char * ipv6; 
  int    port; 
  char * nick; 
  char * user; 
  char * auth;
  char * pass;
};


class cClient {
private:
  cProtocol *Protocol;
public:
  cClient (cProtocol * P);
  
// Messages
  void message ( char * targ,  char * nick,  char * user,  char * host,  char * mess);
  void action  ( char * targ,  char * nick,  char * user,  char * host,  char * mess);
  void notice  ( char * targ,  char * nick,  char * user,  char * host,  char * mess);
  void ctcp    ( char * targ,  char * nick,  char * user,  char * host,  char * mess);
  
// Events
  void join( char * targ,  char * nick,  char * user,  char * host);
  void part( char * targ,  char * nick,  char * user,  char * host,  char * mess);
  void kick( char * chan,  char * kick,  char * mess,  char * nick,  char * user,  char * host);
  void nick( char * nick,  char * user,  char * host,  char * newn);
  void quit( char * nick,  char * user,  char * host,  char * mess);
  void mode( char * nick,  char * user,  char * host,  char * mode,     char * targ);

// Channel Management
  void channel_clear   ( char * chann);
  void channel_add     ( char * chann,  char * nick,  char * user,  char * host,  char *serv,  char *mode,  char *real);
  
// Motd
  void motd_begin      ( char * nick,  char * user,  char * host,  char * mess);
  void motd            ( char * nick,  char * user,  char * host,  char * mess);
  void motd_end        ( char * nick,  char * user,  char * host,  char * mess);
  void motd_missing    ();
  
  void nickchangefail  ( char * oldn,  char * badn,  char * mess,  char * numb);
  void unknown_message ( char * targ,  char * nick,  char * user,  char * host,  char * mess);
};



class cConnection {
  private:
    int Socket;
    cProtocol* Protocol;
    cClient*   Client;
  public: 
    sConnectInfo *ConnectInfo;
    cConnection (sConnectInfo *CI);
    ~cConnection ();
    int Connect();
    int Disconnect();
    int Send(const char *);
    char * ReceiveLn();
    char * Receive0();
};

#endif
