#include <string.h> 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dlfcn.h>
#include "bcp.h"
#include "../c.h"

  cClient * client;
//-----------------------------------------------------------------------------

void __attribute__ ((constructor)) bpp_init(void){
  printf("Loading client library...\n");
}

//-----------------------------------------------------------------------------

void __attribute__ ((destructor)) bpp_fini(void){
  printf("Unloading client library...\n");
}

//-----------------------------------------------------------------------------

char * bc_id(void){
  return (char*)"blaat";
}

//-----------------------------------------------------------------------------
void * bc_init (void * P){
  return (void*) new cClient ( (cProtocol*)P );
}

//-----------------------------------------------------------------------------

cClient::cClient(cProtocol * P){
  Protocol = P;
}

//-----------------------------------------------------------------------------

void cClient::message (char * targ, char * nick, char * user, char * host, char * mess){
  printf("message: ");
  if (mess) { printf("%s\n",mess);
  char * blaat =  strtok (mess," ");
  char * mekker = strtok (NULL,"");
  if (blaat && mekker) 
    if ( strcasecmp("!test",blaat) ==0 )
      if (targ)
        Protocol->sendPRIVMSG(targ,mekker);
      else
        Protocol->sendPRIVMSG(nick,mekker);
  }
}
//-----------------------------------------------------------------------------
void cClient::action  ( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("action: ");
  if (mess) printf("%s\n",mess);
}
//-----------------------------------------------------------------------------
void cClient::notice  ( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("notice: ");
  if (mess) printf("%s\n",mess);
}
//-----------------------------------------------------------------------------
void cClient::ctcp    ( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("ctcp: ");
  if (mess) printf("%s\n",mess);
}
//-----------------------------------------------------------------------------
void cClient::join( char * targ,  char * nick,  char * user,  char * host){
  printf("join: ");
  if (targ && nick && user && host) {
    printf("%s (%s@%s) joined %s\n",nick,user,host,targ);
  }
}
//-----------------------------------------------------------------------------
void cClient::part( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("part: ");
  if (targ && nick && user && host) {
    printf("%s (%s@%s) parted %s",nick,user,host,targ);
    if (mess) printf (" reason : %s",mess); 
    printf("\n");
  }
}
//-----------------------------------------------------------------------------
void cClient::kick( char * chan,  char * kick,  char * mess,  char * nick,  char * user,  char * host){
  printf("kick: ");
}
//-----------------------------------------------------------------------------
void cClient::nick( char * nick,  char * user,  char * host,  char * newn){
    if (newn && nick && user && host) {
      printf("%s (%s@%s) changed nick to%s",nick,user,host,newn);
    }
}
//-----------------------------------------------------------------------------
void cClient::quit( char * nick,  char * user,  char * host,  char * mess){
  printf("quit: ");
}
//-----------------------------------------------------------------------------
void cClient::mode( char * nick,  char * user,  char * host,  char * mode,     char * targ){
  printf("mode: ");
}
//-----------------------------------------------------------------------------
void cClient::channel_clear   ( char * chann){
}
//-----------------------------------------------------------------------------
void cClient::channel_add     ( char * chann,  char * nick,  char * user,  char * host,  char *serv,  char *mode,  char *real){
}
//-----------------------------------------------------------------------------
void cClient::motd_begin      ( char * nick,  char * user,  char * host,  char * mess){
}
//-----------------------------------------------------------------------------
void cClient::motd            ( char * nick,  char * user,  char * host,  char * mess){
}
//-----------------------------------------------------------------------------
void cClient::motd_end        ( char * nick,  char * user,  char * host,  char * mess){
}
//-----------------------------------------------------------------------------
void cClient::motd_missing    (){
}
//-----------------------------------------------------------------------------
void cClient::nickchangefail  ( char * oldn,  char * badn,  char * mess,  char * numb){
}
//-----------------------------------------------------------------------------
void cClient::unknown_message ( char * targ,  char * nick,  char * user,  char * host,  char * mess){
  printf("Unimplemented Message Received! " );
  printf("%s %s %s %s %s\n", targ, nick, user, host, mess);

}
//-----------------------------------------------------------------------------
