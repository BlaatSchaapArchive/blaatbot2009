#ifndef _BLAAT_PROTOCOL_PLUGIN_IRC_
#define _BLAAT_PROTOCOL_PLUGIN_IRC_
#include <pthread.h>
#include "bpp.h"
#include "irc_nummeric.h"
#include "../c.h"
class cConnection;

class cIRCProtocol : public cProtocol {
  private:
  cConnection *Connection;
  pthread_t receivethread;
  void Process           (char * data);
  void SplitUserNickHost (char * data, char * &user, char * &nick, char * &host);
  public:
  cIRCProtocol (cConnection *C);

  void   StartThread ();
  void   ReceiveThread ();
//  void   SendLogin     (char * user, char * nick, char * pass);
  void   SendLogin     ();
  void   SendAuth      ();

  void sendNICK   (const char *nick);
  void sendPRIVMSG(const char *target, const char *message);
  void sendNOTICE (const char *target, const char *message);
  void sendACTION (const char *target, const char *message);
  void sendMODE   (const char *target, const char *mode);
  void sendAWAY   (const char *reason);
  void sendBACK();
  void sendQUIT   (const char *reason);
  void sendRAW    (const char *raw);

};

#endif
